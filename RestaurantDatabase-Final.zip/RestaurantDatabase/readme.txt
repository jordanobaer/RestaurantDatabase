1.Open a project in RubyMine. Choose the RestaurantDatabase as the project's folder.
In the terminal, install the gems:
gem install dm-core
gem install dm-migrations
gem install Zip
gem install csv
gem install bcrypt
gem install sinatra
gem install sinatra-contrib
gem install dm-sqlite-adapter
2.Run main.rb
3.Open Google Chrome and access localhost:4567
4.Create a .csv file with the users. The file contains username, password and role(Student or TA or Instructor) in order, or you can choose the csv file from the folder:example-files
5.Choose the tab 'Upload Users' in the navbar
6.Upload the .csv file with the users
7.Login with an Instructor/TA user
8.Go to the 'Upload Websites' in the navbar
9.Create a zip file with all website folders from the students called 'restaurants', or use the one in the example-files.
For example, each website is stored in a separate folder with the html,css files. The 'restaurants' zip file contains all the different websites folders
10.Upload restaurants.zip
11.Logout from the instructor user and Login as a student
12.Go to the restaurants tab and vote for the websites
13.Logout and Login as an instructor again
14.Go to Vote Report and download the report of the votes
